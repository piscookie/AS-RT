# RT-descriptor-ML
 Performance of each descriptor of chromatographic retention time of arsenic in machine learning
